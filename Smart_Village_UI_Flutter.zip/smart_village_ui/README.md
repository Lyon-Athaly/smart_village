# Smart Village - Source Code Tampilan Flutter

Source code antarmuka berdasarkan empat layar pada PDF kuis Pemrograman Mobile: beranda, daftar rumah sakit, peta lokasi, dan detail fasilitas. Flutter/Dart digunakan karena bahasa atau framework tidak ditentukan dalam permintaan maupun PDF.

## Isi paket

| Berkas | Kegunaan |
| --- | --- |
| `lib/main.dart` | Empat layar, widget bersama, navigasi, dan data contoh. |
| `lib/ui_illustrations.dart` | Gambar desa, gedung fasilitas, dan peta menggunakan CustomPainter. |
| `pubspec.yaml` | Konfigurasi Flutter dengan Material Icons. |
| `analysis_options.yaml` | Konfigurasi analisis tanpa dependensi lint tambahan. |

Paket ini berisi source UI, bukan proyek Android/iOS lengkap atau APK. Folder platform dibuat oleh Flutter di komputer Anda.

## Cara menjalankan

Gunakan Flutter dengan Dart 3.3 atau lebih baru (batas SDK di konfigurasi). Kompatibilitas belum diuji dengan emulator pada lingkungan penyusunan berkas ini.

1. Ekstrak ZIP ke folder kerja. Di dalamnya terdapat folder `smart_village_ui`.
2. Buka terminal dari folder `smart_village_ui`, sejajar dengan `pubspec.yaml`.
3. Buat folder platform Android:

   ```bash
   flutter create --platforms=android --project-name=smart_village_ui .
   ```

   Flutter mengisi berkas proyek yang belum tersedia. Pertahankan `pubspec.yaml`, `analysis_options.yaml`, `lib/main.dart`, dan `lib/ui_illustrations.dart` dari ZIP. Jika IDE mengganti kode dengan contoh counter bawaan, salin ulang keempat berkas tersebut dari ZIP.

4. Perintah `flutter create` dapat membuat `test/widget_test.dart` bawaan untuk aplikasi counter. Hapus berkas tes bawaan tersebut bila masih mengacu pada `MyApp` atau counter; berkas itu bukan tes untuk UI ini.
5. Jalankan:

   ```bash
   flutter pub get
   flutter analyze
   flutter run
   ```

6. Pilih emulator Android yang sudah aktif atau perangkat Android yang tersambung.

Untuk proyek Flutter yang sudah ada, cukup salin dua berkas di `lib/` ke folder `lib/` proyek Anda. Pertahankan dependensi proyek yang sudah ada dan pastikan `flutter: uses-material-design: true` di `pubspec.yaml`.

## Tampilan dan interaksi

| Layar | Tampilan | Interaksi lokal |
| --- | --- | --- |
| Beranda | Header biru muda, ilustrasi desa, kolom pencarian, empat kartu kategori, navigasi bawah. | Pilih kategori, cari fasilitas, buka peta, atau lihat panel profil desa. |
| Daftar fasilitas | Ilustrasi gedung, nama, jarak, jenis fasilitas, chip pelayanan. | Cari nama/alamat/layanan, filter RS Umum atau RS Khusus, buka detail. |
| Peta lokasi | Ilustrasi peta, pin fasilitas, posisi pengguna contoh, lingkaran geofencing, legenda. | Cari lokasi, ketuk pin lalu kartu detail, tampilkan/sembunyikan kategori dan area geofencing. |
| Detail fasilitas | Ilustrasi gedung, nama, tipe, ulasan contoh, alamat, telepon contoh, pelayanan. | Buka peta dengan fasilitas terpilih; tampilkan teks untuk dibagikan. |

Susunan empat layar dan palet warna mengikuti referensi. Foto gedung dan gambar desa diganti ilustrasi lokal yang digambar dari kode; tidak identik piksel demi piksel dengan PDF.

## Batas lingkup

- Semua nama fasilitas, alamat, nomor telepon, jarak, dan ulasan merupakan contoh, bukan informasi layanan kesehatan yang telah diverifikasi.
- Peta adalah ilustrasi lokal; `mapPoint` adalah posisi relatif untuk meletakkan pin, bukan lintang/bujur.
- Lingkaran geofencing hanya elemen visual. Tidak ada perhitungan radius, deteksi masuk/keluar wilayah, atau notifikasi lokasi.
- Tidak ada akses GPS, database, backend, autentikasi, permintaan HTTP, atau integrasi Google Maps.
- Tombol berbagi membuka panel informasi yang dapat diseleksi/disalin manual. Tidak mengirim pesan atau membuka aplikasi lain.
- Setelah dependensi Flutter tersedia, tampilan tidak mengambil aset melalui internet. Tidak memerlukan API key atau izin lokasi.
- Paket ini mengikuti permintaan khusus source tampilan; tidak memenuhi bagian implementasi LBS/geofencing nyata dalam tugas lengkap.

## Mengubah isi dan warna

- Ubah daftar `facilities` di `lib/main.dart` untuk nama, layanan, alamat, jarak, dan posisi pin.
- Ubah konstanta `blue`, `navy`, `green`, dan `purple` untuk warna utama.
- Ubah `HomeScreen`, `FacilityListScreen`, `MapScreen`, dan `DetailScreen` untuk tata letak.
- Ubah painter di `lib/ui_illustrations.dart` untuk ilustrasi.

## Pemeriksaan sebelum digunakan

Flutter SDK dan emulator tidak tersedia pada lingkungan penyusunan, sehingga paket belum dikompilasi atau diuji visual di perangkat. Jalankan `flutter analyze` dan periksa empat layar di emulator Anda. Coba pencarian dengan hasil kosong, filter, navigasi kembali, pin peta, dan tombol Lihat di Peta.

## Dokumentasi resmi

- [Navigasi antarhalaman Flutter](https://docs.flutter.dev/cookbook/navigation/navigation-basics)
- [CustomPaint untuk ilustrasi lokal](https://api.flutter.dev/flutter/widgets/CustomPaint-class.html)

Referensi visual: PDF kuis Pemrograman Mobile yang dilampirkan pengguna.
